--
-- PostgreSQL database dump
--

\restrict rSwkogY6olhhhBtFvpYKfSQvGOdbQsNqBxei8sIE7rf0dob6arKNM6QZXfYgtNF

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: students; Type: TABLE; Schema: public; Owner: week7user
--

CREATE TABLE public.students (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.students OWNER TO week7user;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: week7user
--

CREATE SEQUENCE public.students_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_id_seq OWNER TO week7user;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: week7user
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: week7user
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: week7user
--

COPY public.students (id, name, email, created_at) FROM stdin;
1	Mohsin	mohsin.khan@example.com	2026-01-20 09:37:04.957935
2	Sarah Ahmed	sarah.ahmed@example.com	2026-01-20 09:37:04.957935
3	Hassan Raza	hassan.raza@example.com	2026-01-20 09:37:04.957935
\.


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: week7user
--

SELECT pg_catalog.setval('public.students_id_seq', 3, true);


--
-- Name: students students_email_key; Type: CONSTRAINT; Schema: public; Owner: week7user
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_email_key UNIQUE (email);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: week7user
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict rSwkogY6olhhhBtFvpYKfSQvGOdbQsNqBxei8sIE7rf0dob6arKNM6QZXfYgtNF

